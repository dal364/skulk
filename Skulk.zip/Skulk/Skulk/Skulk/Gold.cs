﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Skulk
{
    public class Gold : Object
    {

        public Gold(Game game)
            : base(game)
        {
        }

        public override void Update(GameTime gameTime)
        {

            base.Update(gameTime);
        }

     


    }
}