﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Audio;

namespace Skulk
{
    static class sound
    {
        // Music
       public static Song normalMusic;
       public static Song Alert;

        //Effec
       public static SoundEffect coinSound;
      
        
    }
}
